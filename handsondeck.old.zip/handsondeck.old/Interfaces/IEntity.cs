﻿namespace HandsOnDeck.Interfaces
{
    internal interface IEntity : IGameObject
    {

    }
}