﻿namespace HandsOnDeck.Enums
{
    public enum HitboxType
    {
        Physical, Trigger
    }
}
