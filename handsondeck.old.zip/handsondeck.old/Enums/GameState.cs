﻿namespace HandsOnDeck.Enums
{    public enum GameState
    {
        Start,
        Settings,
        Game,
        Pause,
        GameOver
    }
}
